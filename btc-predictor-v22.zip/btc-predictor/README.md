# BTC 15-Minute Momentum Lab v2

Node 20+ required. Run `npm start`, then visit http://localhost:3000. Deploy as a Node web service (Render, Railway, Fly.io or VPS), **not** Netlify Drop (static hosting cannot run this backend). Set `PORT` if required and `DATA_DIR` to a persistent mounted volume for historical observations. Public read-only endpoints; no private API keys or trade execution.

## Implemented
- Server-side Kalshi public REST proxy, paginated discovery (up to 1,000 open markets), automatic tentative selection of near-expiring BTC market, and 20-second order-book snapshots.
- Coinbase REST spot polling every 10 seconds and append-only NDJSON history. Frontend additionally uses Coinbase WebSocket.
- Server `/api/status`, `/api/history`, `/api/backtest`, `/api/kalshi/markets...` endpoints.
- Experimental lognormal probability estimate with sample count, freshness flags, and explicit lack of calibration.
- Historical proxy evaluation on collected samples, Brier score and directional accuracy. Requires sufficient days of continuously collected ticks; no fabricated results.
- Mobile UI, web app manifest and local CSV backtesting retained.

## Important limitations
- Kalshi 15-minute discovery is **tentative**; verify the selected ticker, strike, rules, and close time manually. Kalshi market pagination limits may miss a desired contract.
- The server's `floor_strike` is not guaranteed to be the actual settlement target for every market type. Check contract rules.
- Official CF Benchmarks BRTI feed is **not connected**. Coinbase is not an equivalent substitute.
- No real historical Kalshi contract-level backtest or empirically calibrated probabilities. Synthetic-strike proxy backtests are not evidence of profitability.
- No Kalshi authenticated WebSocket or trade execution. Order books are polled, not streamed. No persistence guarantee on ephemeral hosting without a mounted volume.
- Public endpoints should be protected with rate limits and auth before exposing to large audiences. No guarantee of upstream availability.
